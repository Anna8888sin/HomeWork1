import java.io.PrintStream;

public class Main {
    public static void main(String[] args) {
        System.out.println("Иванов Иван Иванович");
        System.out.println("85 лет");
        System.out.println("65 кг");
        System.out.println();
        System.out.println("Петров Пётр Петрович");
        System.out.println("69 лет");
        System.out.println("99 кг");
        System.out.println();
        System.out.println("Сидоров Сидор Сидорович");
        System.out.println("23 лет");
        System.out.println("68 кг");
        System.out.println();
        System.out.println();
        System.out.println();

        System.out.printf("%.2f, ",3.222);
        System.out.printf("%.2f, ", 4.333);
        System.out.printf("%.2f",5.444);
    }



}